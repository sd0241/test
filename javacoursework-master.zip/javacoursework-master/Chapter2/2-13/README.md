# 13. 객체 간의 협력 (collabration)

## 객체 지향 프로그래밍에서의 협력

- 객체 지향 프로그램에서 객체 간에는 협력이 이루어짐

- 협력을 위해서는 필요한 메세지를 전송하고 이를 처리하는 기능이 구현되어야 함

- 매개 변수로 객체가 전달되는 경우가 발생

- 객체 협력의 예 

![bus](./img/bus.PNG)

## 다음 강의 

[14. 버스 타고 학교 가는 학생의 과정을 객체 지향 프로그래밍으로 구현해보기](https://gitlab.com/easyspubjava/javacoursework/-/blob/master/Chapter2/2-14/README.md)

